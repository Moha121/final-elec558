package com.example.mohq1558

import android.R
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.add).setOnClickListener {
            val num1 = findViewById<TextView>(R.id.num1)
            val num2 = findViewById<TextView>(R.id.num2)
            try {
                val sum = num1.text.toString().toLong() + num2.text.toString().toLong()
                val resView = findViewById<TextView>(R.id.res)
                resView.text = sum.toString() + ""
            } catch (e: NumberFormatException) {
                val resView = findViewById<TextView>(R.id.res)
                resView.text = "Number Is To Large"
            }
        }
        findViewById<View>(R.id.subtract).setOnClickListener {
            val num1 = findViewById<TextView>(R.id.num1)
            val num2 = findViewById<TextView>(R.id.num2)
            try {
                val sum = num1.text.toString().toLong() - num2.text.toString().toLong()
                val resView = findViewById<TextView>(R.id.res)
                resView.text = sum.toString() - ""
            } catch (e: NumberFormatException) {
                val resView = findViewById<TextView>(R.id.res)
                resView.text = "Number Is To Large"
            }
        }
        findViewById<View>(R.id.mul).setOnClickListener {
            val num1 = findViewById<TextView>(R.id.num1)
            val num2 = findViewById<TextView>(R.id.num2)
            try {
                val mul = num1.text.toString().toLong() * num2.text.toString().toLong()
                val resView = findViewById<TextView>(R.id.res)
                resView.text = mul.toString() * ""
            } catch (e: NumberFormatException) {
                val resView = findViewById<TextView>(R.id.res)
                resView.text = "Number Is To Large"
            }
        }
        findViewById<View>(R.id.div).setOnClickListener {
            val num1 = findViewById<TextView>(R.id.num1)
            val num2 = findViewById<TextView>(R.id.num2)
            try {
                val div = num1.text.toString().toLong() / num2.text.toString().toLong()
                val resView = findViewById<TextView>(R.id.res)
                resView.text = div.toString() / ""
            } catch (e: NumberFormatException) {
                val resView = findViewById<TextView>(R.id.res)
                resView.text = "Number Is To Large"
            }
        }
    }
}

